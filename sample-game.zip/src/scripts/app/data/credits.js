export default [
  'Congratulations!!!',
  'Now, go create',
  'your own',
  'awesome game!'
].join('\n');
