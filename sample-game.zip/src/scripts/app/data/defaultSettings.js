export default {
  unlockedLevels: [ true, false, false, false, false ],
  soundMuted: false
};
